import React, { useState } from "react";

const ledgerData = [
  { quarter: "Q1", opening: 100000, revenue: 25000, expenses: 10000, profit: 15000, close: 115000 },
  { quarter: "Q2", opening: 115000, revenue: 12000, expenses: 15000, profit: -3000, close: 112000 },
  { quarter: "Q3", opening: 112000, revenue: 20000, expenses: 10000, profit: 10000, close: 122000 },
  { quarter: "Q4", opening: 122000, revenue: 15000, expenses: 10000, profit: 5000, close: 127000 },
];

const staffBoosts = [
  "Sales Team (+10% growth)",
  "Finance (Perfect audit)"
];

export default function Dashboard() {
  const [comments, setComments] = useState([]);
  const [commentInput, setCommentInput] = useState("");

  const totalProfit = ledgerData.reduce((sum, q) => sum + q.profit, 0);
  const opening = ledgerData[0].opening;
  const year = "202X";

  const handleCommentSubmit = e => {
    e.preventDefault();
    if (commentInput.trim()) {
      setComments([commentInput, ...comments]);
      setCommentInput("");
    }
  };

  return (
    <div style={{ maxWidth: 840, margin: "0 auto", fontFamily: "Segoe UI, sans-serif" }}>
      <h2>Organizational Performance Dashboard ({year})</h2>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
        <span><b>Opening Balance:</b> ${opening.toLocaleString()}</span>
        <span><b>Year:</b> {year}</span>
      </div>
      <div style={{ marginBottom: 12 }}>
        {ledgerData.map((q, i) => (
          <span key={q.quarter} style={{ marginRight: 20 }}>
            <b>{q.quarter}:</b> {q.profit < 0 ? "-" : "+"}${Math.abs(q.profit).toLocaleString()}
          </span>
        ))}
      </div>
      <div style={{ marginBottom: 12 }}>
        <b>TOTAL Profit/Loss:</b> ${totalProfit.toLocaleString()}
      </div>
      <h3>Ledger Board</h3>
      <table border="1" cellPadding="6" style={{ width: "100%", marginBottom: 16, borderCollapse: "collapse" }}>
        <thead style={{ background: "#eee" }}>
          <tr>
            <th>Quarter</th>
            <th>Opening</th>
            <th>Revenue</th>
            <th>Expenses</th>
            <th>Profit</th>
            <th>Close</th>
          </tr>
        </thead>
        <tbody>
          {ledgerData.map(q => (
            <tr key={q.quarter}>
              <td>{q.quarter}</td>
              <td>${q.opening.toLocaleString()}</td>
              <td>${q.revenue.toLocaleString()}</td>
              <td>${q.expenses.toLocaleString()}</td>
              <td style={{ color: q.profit < 0 ? "red" : "green" }}>
                {q.profit < 0 ? "-" : "+"}${Math.abs(q.profit).toLocaleString()}
              </td>
              <td>${q.close.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ marginBottom: 16 }}>
        <b>Staff Boosts/Achievements:</b>
        <ul>
          {staffBoosts.map(b => <li key={b}>{b}</li>)}
        </ul>
      </div>
      <div style={{ marginBottom: 16 }}>
        <b>Profit Trend per Quarter</b>
        <div style={{ height: 120, background: "#fafafa", border: "1px solid #ccc", display: "flex", alignItems: "end", gap: 16, padding: 8 }}>
          {ledgerData.map((q, i) => (
            <div key={q.quarter} style={{ textAlign: "center", width: 60 }}>
              <div style={{
                height: Math.max(10, Math.abs(q.profit) / 200),
                background: q.profit < 0 ? "#d22" : "#2d2",
                width: "100%",
                marginBottom: 6,
                borderRadius: 4,
                transition: "height 0.4s"
              }} />
              <span>{q.quarter}</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <b>Staff Comments & Suggestions:</b>
        <form onSubmit={handleCommentSubmit} style={{ margin: "8px 0" }}>
          <input
            value={commentInput}
            onChange={e => setCommentInput(e.target.value)}
            placeholder="Share your thoughts..."
            style={{ width: 320, padding: 6, marginRight: 8 }}
          />
          <button type="submit">Submit</button>
        </form>
        <ul>
          {comments.map((c, i) => <li key={i}>{c}</li>)}
        </ul>
      </div>
    </div>
  );
}